function addition(a: number, b: number): number {
    return a + b
}

console.log(addition(2, 2));

function stringToUpperCase(str: string): string {
    return str.toUpperCase()
}

console.log(stringToUpperCase('hello all!!!'));
